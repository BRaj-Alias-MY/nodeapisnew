'use strict';
module.exports = (sequelize, DataTypes) => {
  const Discount = sequelize.define('Discount', {
    course_id: DataTypes.INTEGER,
    amount: DataTypes.INTEGER
  }, {});
  Discount.associate = function(models) {
    // associations can be defined here
    Discount.belongsTo(models.Course, {
      foreignKey: 'course_id',
      as: 'courses'
    });
  };
  return Discount;
};