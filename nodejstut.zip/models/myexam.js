'use strict';
module.exports = (sequelize, DataTypes) => {
  const myexam = sequelize.define('myexam', {
    q_title: DataTypes.STRING,
    ano: DataTypes.INTEGER,
    uid: DataTypes.STRING,
    answer: DataTypes.STRING,
    userId: DataTypes.INTEGER,
    status: DataTypes.INTEGER
  }, {});
  myexam.associate = function(models) {
    // associations can be defined here
  };
  return myexam;
};