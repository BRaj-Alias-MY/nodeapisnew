const MyExam = require ('../models').myexam;
//const jwt = require ('jsonwebtoken');

 

exports.findOne = (req, res) => {
  MyExam.findOne ({where: {id: req.params.id, status: 0} })
    .then (exam => {
      // Send all customers to Client
      if (exam) {
        res.send (exam);
      } else {
        res.send ({message: 'no data found!'});
      }
    })
    .catch (err => res.send ('unable to access'));
};
