const Course = require('../models').Course;

exports.Create = (req,res) => {
    Course.create({
        title: req.body.title
    })
    .then(course=>{res.json(course)})
    .catch(err=>{res.json(err)})
}